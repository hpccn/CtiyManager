package android.support.v4.view;

import android.view.View;

public class ViewCompatJellybeanMr1
{
  public static int getLabelFor(View paramView)
  {
    return paramView.getLabelFor();
  }

  public static void setLabelFor(View paramView, int paramInt)
  {
    paramView.setLabelFor(paramInt);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatJellybeanMr1
 * JD-Core Version:    0.6.0
 */