package android.support.v4.widget;

import android.widget.Scroller;

class ScrollerCompatIcs
{
  public static float getCurrVelocity(Scroller paramScroller)
  {
    return paramScroller.getCurrVelocity();
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ScrollerCompatIcs
 * JD-Core Version:    0.6.0
 */