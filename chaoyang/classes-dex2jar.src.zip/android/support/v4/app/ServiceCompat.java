package android.support.v4.app;

public class ServiceCompat
{
  public static final int START_STICKY = 1;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ServiceCompat
 * JD-Core Version:    0.6.0
 */