package com.cymobile.ymwork.act;

import android.app.Activity;

public class SearchableActivity extends Activity
{
  public void onDeleteItemButtonClick(String paramString)
  {
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.act.SearchableActivity
 * JD-Core Version:    0.6.0
 */