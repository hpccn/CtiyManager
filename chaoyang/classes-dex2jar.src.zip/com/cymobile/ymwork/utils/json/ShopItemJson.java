package com.cymobile.ymwork.utils.json;

import com.cymobile.ymwork.types.Building;
import java.io.InputStream;
import java.util.List;

public class ShopItemJson
{
  public static List<Building> getNewsList(InputStream paramInputStream)
  {
    return null;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.utils.json.ShopItemJson
 * JD-Core Version:    0.6.0
 */