package com.cymobile.ymwork.types;

public abstract interface BaseType
{
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.types.BaseType
 * JD-Core Version:    0.6.0
 */