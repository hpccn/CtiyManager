package com.cymobile.ymwork;

public class Constant
{
  public static final String API_DOMAIN = "203.86.54.62";
  public static final int API_PORT = 8080;
  public static final String CONSUMER_KEY = "";
  public static final String CONSUMER_SECRET = "";
  public static final String INTENT_ACTION_CASE_NUMBER_UPDATED = "com.cymobile.ymwork.intent.action.CASE_NUMBER_UPDATED";
  public static final String INTENT_ACTION_FetechVersion_Done = "com.cymobile.ymwork.intent.action.versionfetchdone";
  public static final String INTENT_ACTION_LOCATED = "com.cymobile.ymwork.intent.action.located";
  public static final String INTENT_ACTION_LOGGED_IN = "com.cymobile.ymwork.intent.action.LOGGED_IN";
  public static final String INTENT_ACTION_LOGGED_OUT = "com.cymobile.ymwork.intent.action.LOGGED_OUT";
  public static final String PACKAGE = "com.cymobile.ymwork";
  public static final int Version = 0;
  public static final int Version_Normal = 0;
  public static final int Version_Super = 1;
  public static final String WEIBO_CONSUMER_KEY = "3831439438";
  public static final String WEIBO_CONSUMER_SECRET = "9e52f85323406313b3b4749ef9503e62";
  public static final String WEIBO_REDIRECT = "http://weibo.com/u/3353359810";
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.Constant
 * JD-Core Version:    0.6.0
 */