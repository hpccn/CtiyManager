package com.cymobile.ymwork.search;

public abstract interface ISearchBarChangeObserver
{
  public abstract void onSearchBarChange(int paramInt, String paramString);
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.search.ISearchBarChangeObserver
 * JD-Core Version:    0.6.0
 */