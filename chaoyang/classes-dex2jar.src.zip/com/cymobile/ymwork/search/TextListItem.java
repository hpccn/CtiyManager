package com.cymobile.ymwork.search;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class TextListItem extends LinearLayout
{
  public TextListItem(Context paramContext)
  {
    super(paramContext);
  }

  public TextListItem(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.cymobile.ymwork.search.TextListItem
 * JD-Core Version:    0.6.0
 */