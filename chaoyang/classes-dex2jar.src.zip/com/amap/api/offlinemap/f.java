package com.amap.api.offlinemap;

public class f
{
  private String a;
  private String b;
  private String c;
  private int d;

  public f()
  {
    this("", "", "", 5);
  }

  public f(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramInt;
  }

  public String a()
  {
    return this.a;
  }

  public String b()
  {
    return this.b;
  }

  public String c()
  {
    return this.c;
  }

  public int d()
  {
    return this.d;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.offlinemap.f
 * JD-Core Version:    0.6.0
 */