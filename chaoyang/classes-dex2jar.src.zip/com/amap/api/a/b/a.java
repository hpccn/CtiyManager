package com.amap.api.a.b;

public class a extends Exception
{
  private String a = "未知的错误";

  public a()
  {
  }

  public a(String paramString)
  {
    this.a = paramString;
  }

  public String a()
  {
    return this.a;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.b.a
 * JD-Core Version:    0.6.0
 */