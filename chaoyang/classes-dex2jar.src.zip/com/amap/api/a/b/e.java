package com.amap.api.a.b;

public class e
{
  public static void a(String paramString1, String paramString2, int paramInt)
  {
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.b.e
 * JD-Core Version:    0.6.0
 */