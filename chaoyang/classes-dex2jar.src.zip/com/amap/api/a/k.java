package com.amap.api.a;

public class k
{
  static float a = 0.9F;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.k
 * JD-Core Version:    0.6.0
 */