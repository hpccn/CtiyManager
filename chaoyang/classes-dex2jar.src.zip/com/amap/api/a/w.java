package com.amap.api.a;

import android.os.RemoteException;

public abstract interface w
{
  public abstract void a(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean a()
    throws RemoteException;

  public abstract void b(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean b()
    throws RemoteException;

  public abstract void c(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean c()
    throws RemoteException;

  public abstract void d(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean d()
    throws RemoteException;

  public abstract void e(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean e()
    throws RemoteException;

  public abstract void f(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean f()
    throws RemoteException;

  public abstract void g(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean g()
    throws RemoteException;

  public abstract void h(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean h()
    throws RemoteException;

  public abstract void i(boolean paramBoolean)
    throws RemoteException;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.w
 * JD-Core Version:    0.6.0
 */