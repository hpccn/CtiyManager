package com.amap.api.a;

class z
{
  int a;
  boolean b;

  public z(int paramInt)
  {
    this.a = paramInt;
  }

  public z a(boolean paramBoolean)
  {
    this.b = paramBoolean;
    return this;
  }

  public boolean a()
  {
    return this.b;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.z
 * JD-Core Version:    0.6.0
 */