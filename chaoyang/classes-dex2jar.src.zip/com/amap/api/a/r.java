package com.amap.api.a;

import android.os.RemoteException;
import javax.microedition.khronos.opengles.GL10;

public abstract interface r
{
  public abstract void a()
    throws RemoteException;

  public abstract void a(float paramFloat)
    throws RemoteException;

  public abstract void a(GL10 paramGL10)
    throws RemoteException;

  public abstract void a(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean a(r paramr)
    throws RemoteException;

  public abstract String b()
    throws RemoteException;

  public abstract float c()
    throws RemoteException;

  public abstract boolean d()
    throws RemoteException;

  public abstract int e()
    throws RemoteException;

  public abstract void f()
    throws RemoteException;

  public abstract void m();
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.a.r
 * JD-Core Version:    0.6.0
 */