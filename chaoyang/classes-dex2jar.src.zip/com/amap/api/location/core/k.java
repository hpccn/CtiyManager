package com.amap.api.location.core;

import java.net.Proxy;

public abstract class k<T, V>
{
  protected Proxy a;
  protected T b;
  protected int c = 1;
  protected int d = 20;
  protected int e = 0;
  protected int f = 0;
  protected String g;
  protected String h = "";

  public k(T paramT, Proxy paramProxy, String paramString1, String paramString2)
  {
    this.a = paramProxy;
    this.b = paramT;
    this.c = 1;
    this.d = 5;
    this.e = 2;
    this.g = paramString2;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.location.core.k
 * JD-Core Version:    0.6.0
 */