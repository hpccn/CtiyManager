package com.amap.api.location.core;

public class e
{
  public static int a = 18;
  public static int b = 3;
  public static int c = 20;
  public static int d = 3;
  public static int e = 0;
  public static int f = 0;
  public static GeoPoint.a g = GeoPoint.a.a;
  public static int h = 0;
  public static int i = 0;
  public static String j = "V1.0.0";
  public static String k = "V1.0.0";
  public static boolean l = true;
  public static boolean m = true;
  public static boolean n = false;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.location.core.e
 * JD-Core Version:    0.6.0
 */