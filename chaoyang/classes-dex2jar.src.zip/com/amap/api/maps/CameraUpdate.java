package com.amap.api.maps;

import com.amap.api.a.h;

public final class CameraUpdate
{
  h a;

  CameraUpdate(h paramh)
  {
    this.a = paramh;
  }

  h a()
  {
    return this.a;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.maps.CameraUpdate
 * JD-Core Version:    0.6.0
 */