package com.amap.api.search.geocoder;

class b
{
  public String a;
  public int b;
  public String c;

  public b(String paramString1, String paramString2, int paramInt)
  {
    this.a = paramString1;
    this.c = paramString2;
    this.b = paramInt;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.search.geocoder.b
 * JD-Core Version:    0.6.0
 */