package com.amap.api.search.geocoder;

public class d
{
  public double a;
  public double b;
  public int c;
  public boolean d;

  public d(double paramDouble1, double paramDouble2, int paramInt, boolean paramBoolean)
  {
    this.a = paramDouble1;
    this.b = paramDouble2;
    this.c = paramInt;
    this.d = paramBoolean;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.search.geocoder.d
 * JD-Core Version:    0.6.0
 */