package com.amap.api.search.core;

public class c
{
  public static int a = 0;
  public static int b = 0;
  public static String c = "V1.0.0";
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.amap.api.search.core.c
 * JD-Core Version:    0.6.0
 */