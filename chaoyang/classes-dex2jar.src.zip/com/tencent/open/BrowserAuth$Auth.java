package com.tencent.open;

import com.tencent.tauth.IUiListener;

public class BrowserAuth$Auth
{
  public IUiListener a;
  public TDialog b;
  public String c;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.open.BrowserAuth.Auth
 * JD-Core Version:    0.6.0
 */