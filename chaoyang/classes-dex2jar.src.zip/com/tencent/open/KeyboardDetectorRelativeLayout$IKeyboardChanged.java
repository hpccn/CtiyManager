package com.tencent.open;

public abstract interface KeyboardDetectorRelativeLayout$IKeyboardChanged
{
  public abstract void onKeyboardHidden();

  public abstract void onKeyboardShown(int paramInt);
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.open.KeyboardDetectorRelativeLayout.IKeyboardChanged
 * JD-Core Version:    0.6.0
 */