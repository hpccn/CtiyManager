package com.tencent.open;

class g
{
  private g(RedoDialog paramRedoDialog)
  {
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.open.g
 * JD-Core Version:    0.6.0
 */