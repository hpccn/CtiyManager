package com.tencent.open;

public class HttpStatusException extends Exception
{
  public HttpStatusException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.open.HttpStatusException
 * JD-Core Version:    0.6.0
 */