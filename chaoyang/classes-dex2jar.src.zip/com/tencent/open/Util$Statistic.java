package com.tencent.open;

public class Util$Statistic
{
  public String a;
  public long b;
  public long c;

  public Util$Statistic(String paramString, int paramInt)
  {
    this.a = paramString;
    this.b = paramInt;
    if (this.a != null)
      this.c = this.a.length();
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.open.Util.Statistic
 * JD-Core Version:    0.6.0
 */