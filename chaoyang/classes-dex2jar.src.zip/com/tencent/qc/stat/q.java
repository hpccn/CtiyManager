package com.tencent.qc.stat;

abstract interface q
{
  public abstract void a();

  public abstract void b();
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.q
 * JD-Core Version:    0.6.0
 */