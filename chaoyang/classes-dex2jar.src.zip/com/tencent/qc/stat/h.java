package com.tencent.qc.stat;

import java.util.List;

class h
  implements Runnable
{
  h(StatStore paramStatStore, List paramList, int paramInt)
  {
  }

  public void run()
  {
    StatStore.a(this.c, this.a, this.b);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.h
 * JD-Core Version:    0.6.0
 */