package com.tencent.qc.stat;

import java.util.List;

class o
  implements Runnable
{
  o(l paraml, List paramList, q paramq)
  {
  }

  public void run()
  {
    this.c.a(this.a, this.b);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.o
 * JD-Core Version:    0.6.0
 */