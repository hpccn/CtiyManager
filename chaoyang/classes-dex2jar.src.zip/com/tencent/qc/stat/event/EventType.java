package com.tencent.qc.stat.event;

public enum EventType
{
  private int f;

  static
  {
    EventType[] arrayOfEventType = new EventType[5];
    arrayOfEventType[0] = a;
    arrayOfEventType[1] = b;
    arrayOfEventType[2] = c;
    arrayOfEventType[3] = d;
    arrayOfEventType[4] = e;
    g = arrayOfEventType;
  }

  private EventType(int arg3)
  {
    int j;
    this.f = j;
  }

  public int a()
  {
    return this.f;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.event.EventType
 * JD-Core Version:    0.6.0
 */