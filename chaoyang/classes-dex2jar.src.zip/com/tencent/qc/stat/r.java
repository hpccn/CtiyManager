package com.tencent.qc.stat;

class r
{
  long a;
  String b;
  int c;
  int d;

  public r(long paramLong, String paramString, int paramInt1, int paramInt2)
  {
    this.a = paramLong;
    this.b = paramString;
    this.c = paramInt1;
    this.d = paramInt2;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.r
 * JD-Core Version:    0.6.0
 */