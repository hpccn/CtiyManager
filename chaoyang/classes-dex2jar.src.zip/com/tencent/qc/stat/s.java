package com.tencent.qc.stat;

import org.json.JSONObject;

class s
{
  int a;
  JSONObject b = new JSONObject();
  String c = "";
  int d = 0;

  public s(int paramInt)
  {
    this.a = paramInt;
  }

  String a()
  {
    if (this.b.length() == 0)
      return "";
    return this.b.toString();
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.qc.stat.s
 * JD-Core Version:    0.6.0
 */