package com.tencent.plus;

class a
  implements Runnable
{
  a(g paramg, String paramString)
  {
  }

  public void run()
  {
    ImageActivity.b(this.b.a, this.a);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.plus.a
 * JD-Core Version:    0.6.0
 */