package com.tencent.plus;

class k
  implements Runnable
{
  k(i parami)
  {
  }

  public void run()
  {
    ImageActivity.g(this.a.a);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.plus.k
 * JD-Core Version:    0.6.0
 */