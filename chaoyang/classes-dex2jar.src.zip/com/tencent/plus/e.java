package com.tencent.plus;

class e
  implements Runnable
{
  e(ImageActivity paramImageActivity, String paramString, int paramInt)
  {
  }

  public void run()
  {
    ImageActivity.a(this.c, this.a, this.b);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.plus.e
 * JD-Core Version:    0.6.0
 */