package com.tencent.plus;

public class AvatarConstants
{
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.tencent.plus.AvatarConstants
 * JD-Core Version:    0.6.0
 */