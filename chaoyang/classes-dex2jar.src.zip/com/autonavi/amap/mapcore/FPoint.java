package com.autonavi.amap.mapcore;

public class FPoint
{
  public float x;
  public float y;

  public FPoint()
  {
  }

  public FPoint(float paramFloat1, float paramFloat2)
  {
    this.x = paramFloat1;
    this.y = paramFloat2;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.FPoint
 * JD-Core Version:    0.6.0
 */