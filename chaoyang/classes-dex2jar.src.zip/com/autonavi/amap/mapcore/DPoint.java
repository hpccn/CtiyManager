package com.autonavi.amap.mapcore;

public class DPoint
{
  public double x;
  public double y;

  public DPoint()
  {
  }

  public DPoint(double paramDouble1, double paramDouble2)
  {
    this.x = paramDouble1;
    this.y = paramDouble2;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.DPoint
 * JD-Core Version:    0.6.0
 */