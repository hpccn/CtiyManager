package com.autonavi.amap.mapcore;

class b
{
  String a;
  int b;

  public b(String paramString, int paramInt)
  {
    this.a = paramString;
    this.b = paramInt;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.b
 * JD-Core Version:    0.6.0
 */