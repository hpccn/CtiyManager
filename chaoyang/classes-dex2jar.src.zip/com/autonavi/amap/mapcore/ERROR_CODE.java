package com.autonavi.amap.mapcore;

public class ERROR_CODE
{
  public static final int CONN_CREATE_FALSE = 1001;
  public static final int CONN_ERROR = 1002;
  public static final int ERROR_NONE;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.ERROR_CODE
 * JD-Core Version:    0.6.0
 */