package com.autonavi.amap.mapcore;

class a
{
  public int a;
  public String b;
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.a
 * JD-Core Version:    0.6.0
 */