package com.autonavi.amap.mapcore;

public class IPoint
{
  public int x;
  public int y;

  public IPoint()
  {
  }

  public IPoint(int paramInt1, int paramInt2)
  {
    this.x = paramInt1;
    this.y = paramInt2;
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.IPoint
 * JD-Core Version:    0.6.0
 */