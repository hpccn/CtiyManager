package com.autonavi.amap.mapcore;

class e
{
  byte[] a;
  String b;
  int c;

  public e(String paramString, byte[] paramArrayOfByte)
  {
    this.b = paramString;
    this.a = paramArrayOfByte;
    this.c = (int)(System.currentTimeMillis() / 1000L);
  }
}

/* Location:           /mnt/data/hpc-dev/hou/20131220/同步更新文档说明20131220/classes-dex2jar.jar
 * Qualified Name:     com.autonavi.amap.mapcore.e
 * JD-Core Version:    0.6.0
 */